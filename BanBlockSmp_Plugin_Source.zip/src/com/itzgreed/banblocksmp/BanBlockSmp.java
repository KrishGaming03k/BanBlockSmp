package com.itzgreed.banblocksmp;

import org.bukkit.plugin.java.JavaPlugin;

public class BanBlockSmp extends JavaPlugin {
    @Override
    public void onEnable() {
        getLogger().info("BanBlockSmp has been enabled!");
        saveDefaultConfig();
        // Register events and commands here
    }

    @Override
    public void onDisable() {
        getLogger().info("BanBlockSmp has been disabled.");
    }
}
