package me.itzgreed.banblocksmp;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

public class BanBlockSmp extends JavaPlugin implements Listener {
    private final Map<UUID, Material> bannedBlocks = new HashMap<>();
    private final Set<UUID> bannedPlayers = new HashSet<>();
    private final List<Material> blockOptions = new ArrayList<>();
    private final Map<UUID, UUID> sacrificeRequests = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        loadBlockOptions();
        getLogger().info("BanBlockSmp has been enabled!");
    }

    private void loadBlockOptions() {
        List<String> options = getConfig().getStringList("banned-blocks");
        for (String option : options) {
            try {
                blockOptions.add(Material.valueOf(option.toUpperCase()));
            } catch (IllegalArgumentException e) {
                getLogger().warning("Invalid block in config: " + option);
            }
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (!bannedBlocks.containsKey(player.getUniqueId())) {
            assignRandomBlock(player);
        }
    }

    private void assignRandomBlock(Player player) {
        Random random = new Random();
        Material chosen = blockOptions.get(random.nextInt(blockOptions.size()));
        bannedBlocks.put(player.getUniqueId(), chosen);
        BossBar bar = Bukkit.createBossBar("§cYour banned block is: §f" + chosen.name(), BarColor.RED, BarStyle.SOLID);
        bar.addPlayer(player);
        bar.setVisible(true);
        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
        Bukkit.getScheduler().runTaskLater(this, () -> bar.setVisible(false), 100L);
    }

    @EventHandler
    public void onStep(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (!bannedBlocks.containsKey(player.getUniqueId())) return;
        if (bannedPlayers.contains(player.getUniqueId())) return;

        Material standingOn = player.getLocation().subtract(0, 1, 0).getBlock().getType();
        if (standingOn == bannedBlocks.get(player.getUniqueId())) {
            player.kickPlayer("§cYou stepped on your banned block: " + standingOn.name());
            Bukkit.getBanList(org.bukkit.BanList.Type.NAME).addBan(player.getName(), "You stepped on your banned block: " + standingOn.name(), null, null);
            bannedPlayers.add(player.getUniqueId());
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("unbanblock")) {
            if (args.length != 1) return false;
            OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
            Bukkit.getBanList(org.bukkit.BanList.Type.NAME).pardon(target.getName());
            bannedPlayers.remove(target.getUniqueId());
            bannedBlocks.remove(target.getUniqueId());
            return true;
        }
        return false;
    }
}